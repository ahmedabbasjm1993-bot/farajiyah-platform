package com.farajia.app;
import android.content.Context; import android.content.SharedPreferences; import android.webkit.JavascriptInterface;
public class NativeStore {
 private final SharedPreferences p; public NativeStore(Context c){p=c.getSharedPreferences("farajia_sync",Context.MODE_PRIVATE);}
 @JavascriptInterface public void mirror(String key,String value){ if(key==null)return; p.edit().putString("data:"+key,value==null?"":value).apply(); p.edit().putBoolean("dirty:"+key,true).apply(); }
 @JavascriptInterface public void remove(String key){ if(key==null)return; p.edit().remove("data:"+key).putBoolean("dirty:"+key,true).apply(); }
 @JavascriptInterface public String getRemote(String key){return p.getString("remote:"+key,null);}
 @JavascriptInterface public void clearRemote(String key){p.edit().remove("remote:"+key).apply();}
}
