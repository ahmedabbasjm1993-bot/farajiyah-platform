package com.farajia.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

public class MainActivity extends AppCompatActivity {
    private WebView web;
    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new NativeStore(this), "AndroidSync");
        web.loadUrl("file:///android_asset/index.html");
        enqueueSync();
    }
    private void enqueueSync(){
        Constraints c=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest r=new OneTimeWorkRequest.Builder(SyncWorker.class).setConstraints(c).build();
        WorkManager.getInstance(this).enqueueUniqueWork("farajia-sync", ExistingWorkPolicy.KEEP, r);
    }
    @Override protected void onDestroy(){ if(web!=null) web.destroy(); super.onDestroy(); }
}
